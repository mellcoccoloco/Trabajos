import flet as ft
from time import sleep

def main(page: ft.Page):
    songs = [
        {
            "src": "/Users/coccoo/Desktop/song1.mp3",
            "title": "Wild Flower - Billie",
            "cover": "/Users/coccoo/Desktop/cover1.png"
        },
        {
            "src": "/Users/coccoo/Desktop/song2.mp3",
            "title": "I Love You - Billie",
            "cover": "/Users/coccoo/Desktop/cover2.png"
        },
        {
            "src": "/Users/coccoo/Desktop/song3.mp3",
            "title": "Golden Hour - JVKE",
            "cover": "/Users/coccoo/Desktop/cover3.png"
        },
        {
            "src": "/Users/coccoo/Desktop/song4.mp3",
            "title": "Sweater Weather - The Neighbourhood",
            "cover": "/Users/coccoo/Desktop/cover4.png"
        },
        {
            "src": "/Users/coccoo/Desktop/song5.mp3",
            "title": "Another Love - Tom Odell",
            "cover": "/Users/coccoo/Desktop/cover5.png"
        }
    ]
    current_index = 0
    is_playing = [False]
    duration = [0]
    audios = [ft.Audio(src=song["src"], autoplay=False, volume=1) for song in songs]

    album_cover = ft.Image(src=songs[0]["cover"], width=200, height=200, fit=ft.ImageFit.CONTAIN)
    song_name = ft.Text(songs[0]["title"], size=20, weight=ft.FontWeight.BOLD)
    progress_bar = ft.ProgressBar(width=300, height=10, value=0)

    def play_audio(index):
        for audio in audios:
            audio.pause()
        
        audios[index].play()
        song_name.value = songs[index]["title"]
        album_cover.src = songs[index]["cover"]

        song_name.update()
        album_cover.update()

        update_progress_bar(index)

    def update_progress_bar(index):
        def progress_loop():
            while audios[index].playing:
                progress_bar.value = min(1, progress_bar.value + 0.01)
                progress_bar.update()
                sleep(0.5)
        
        progress_bar.value = 0  
        page.run_task(progress_loop)  

    total_duration = 1  

    def update_duration(duration):
        nonlocal total_duration
        total_duration = int(duration) / 1000 

    def update_progress(position):
        position = int(position) / 1000 
        progress_bar.value = position / total_duration if total_duration > 0 else 0
        progress_bar.update()

    def next_song(_):
        nonlocal current_index
        current_index = (current_index + 1) % len(audios)
        play_audio(current_index)

    def previous_song(_):
        nonlocal current_index
        current_index = (current_index - 1) % len(audios)
        play_audio(current_index)

    def volume_down(_):
        audios[current_index].volume = max(0, audios[current_index].volume - 0.1)
        audios[current_index].update()

    def volume_up(_):
        audios[current_index].volume = min(1, audios[current_index].volume + 0.1)
        audios[current_index].update()


    file_picker = ft.FilePicker()
    page.overlay.append(file_picker)

    def file_picker_result(e: ft.FilePickerResultEvent):
        if e.files is not None and len(e.files) > 0:
            selected_song = e.files[0].path
            audios[current_index].src = selected_song
            song_name.value = "Now Playing: " + selected_song.split("\\")[-1][:-4]
            album_cover.src = ""
            progress_bar.value = 0
            audios[current_index].play()
            is_playing[0] = True
            album_cover.src = "https://play-lh.googleusercontent.com/CQri0N-BiyrACHpHPPtITg3TMV5-bZNbAuhjrg-Zpc_mw6tIWZJFPmT8Yr5r4R-xbA=w240-h480-rw"
            page.update()
    file_picker.on_result = file_picker_result

    file_picker_btn = ft.ElevatedButton(
        text="Select Song",
        icon=ft.icons.FOLDER_OPEN,
        on_click=lambda e: file_picker.pick_files(
            allow_multiple=False,
            file_type=ft.FilePickerFileType.AUDIO
        )
    )

    page.overlay.extend(audios)

    page.add(
        album_cover,
        song_name,
        progress_bar,
        file_picker_btn,
        ft.ElevatedButton("Play", on_click=lambda _: audios[current_index].play()),
        ft.ElevatedButton("Pause", on_click=lambda _: audios[current_index].pause()),
        ft.ElevatedButton("Resume", on_click=lambda _: audios[current_index].resume()),
        ft.Row([
            ft.ElevatedButton("Volume down", on_click=volume_down),
            ft.ElevatedButton("Volume up", on_click=volume_up),
        ]),
        ft.ElevatedButton("Next Song", on_click=next_song),
        ft.ElevatedButton("Previous Song", on_click=previous_song),
    )

ft.app(main)
